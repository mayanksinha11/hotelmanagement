package com.cg.hrb.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.hrb.entity.BookingDetails;
import com.cg.hrb.entity.HotelDetails;
import com.cg.hrb.service.IBookingService;

@Controller
public class BookingController {

	@Autowired
	IBookingService bser;
	
	
	@RequestMapping("home")
	public String goHome(Model model){
		List<HotelDetails> hlist=bser.getAllHotels();
		model.addAttribute("hlist",hlist);
		model.addAttribute("book",new BookingDetails());
		return "Register";
	}
	
	@RequestMapping("register")
	public String register(@ModelAttribute("book") @Valid BookingDetails book, BindingResult res,Model model){
		if(res.hasErrors()){
			List<HotelDetails> hlist=bser.getAllHotels();
			model.addAttribute("hlist",hlist);
			model.addAttribute("book",book);
			
			return "Register";
		}
		else {
			long id= bser.insertBookingDetails(book);
			model.addAttribute("id", id);
						return "Success";
		}
		}
	
	
	
	
}
