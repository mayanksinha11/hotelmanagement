package com.cg.hrb.dao;

import java.util.List;

import com.cg.hrb.entity.BookingDetails;
import com.cg.hrb.entity.HotelDetails;

public interface IBookingDao {

	long insertBookingDetails(BookingDetails book);
	List<HotelDetails> getAllHotels();
	
}
