package com.cg.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotel;
import com.cg.bean.Roomdetails;
import com.cg.bean.Users;
import com.cg.exception.BookingException;

public interface IBookingDAO {

	public boolean validateDetails(Users user)throws BookingException;
	public String addUser(Users user)throws BookingException;//Hogaya
	public boolean validateUser(String mobileNo,String password)throws BookingException;
	public List<Hotel> viewAllHotels()throws BookingException;//Hogaya
	public List<Roomdetails> getAllRooms(String hotelId)throws BookingException;//Hogaya
	public BookingDetails addBookingDetails(BookingDetails bookingDetails)throws BookingException;
	public BookingDetails viewBookingDetails(String bookingId) throws BookingException;//Hogaya
	public String addHotel(Hotel hotel) throws BookingException;//Hogaya//me
//	public int deleteHotel(String hotelId);//apurva
//	public Hotel updateHotel(Hotel hotel);//vansh
//	public RoomDetails addRoom(RoomDetails room);//Hogaya
//	public int deleteRoom(RoomDetails room);//soumya
//	public RoomDetails updateRoom(RoomDetails room);//updae
//	public List<BookingDetails> viewBookingDetails(String hotelId);//deepika
//	public List<Users> getGuestList(String hotelId);
//	public List<BookingDetails> viewBookings(LocalDate date);//deepika

}
