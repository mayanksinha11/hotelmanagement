package com.cg.presentation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotel;
import com.cg.bean.Roomdetails;
import com.cg.bean.Users;
import com.cg.dao.BookingDAOImpl;
import com.cg.dao.IBookingDAO;
import com.cg.exception.BookingException;
import com.cg.service.BookingServiceImpl;
import com.cg.service.IBookingService;

public class Client 
{
	IBookingService service;

	public Client() 
	{
		super();
		service = new BookingServiceImpl();
	}

	public static void main(String[] args) 
	{

		Client c = new Client();
		System.out.print("\n\t Welcome to Hotel Booking Management System\n"
				+ "1. Register into the system ( For new User ).\n"
				+ "2. Login to the system as Admin.\n"+ "3. Login to the system as User.\n"
				+ " Enter choice: ");
		Scanner sc = new Scanner(System.in);
		int ch = sc.nextInt();
		switch(ch)
		{
		case 1:
			c.register();
			break;	
		case 2:
		{
			System.out.println("Enter Admin User name");
			String usnm=sc.next();
			System.out.println("Enter Admin Pasword");
			String pswd=sc.next();
			if(usnm.equals("admin")&&pswd.equals("admin"))
			{
				System.out.println("1.Add Hotel ");
				System.out.println("2.Update Hotel Details");
				System.out.println("3.Add Rooms");
				System.out.println("4.Delete Room");
				System.out.println("5.Update Rooms details");
				System.out.println("6.View Booking details based on Hotel");
				System.out.println("7.View Guest List for a Hotel");
				System.out.println("8.View Booking Details based on Date");
				System.out.println("Enter Choice");
				int ch1=sc.nextInt();
				Hotel hotel= new Hotel();
				IBookingDAO serv= new BookingDAOImpl();
				switch (ch1) {
				case 1:
					System.out.print("Enter Hotel City: ");
					String city = sc.next();
					hotel.setCity(city);
					System.out.print("Enter Hotel Name: ");
					String hotelName = sc.next();
					hotel.setHotelName(hotelName);
					System.out.print("Enter Address ");
					String address = sc.next();
					hotel.setAddress(address);
					System.out.print("Enter Description ");
					String desc = sc.next();
					hotel.setDescription(desc);
					System.out.print(" Enter Average rate per night ");
					double avg = sc.nextDouble();
					hotel.setAverageRatePerNight(avg);
					System.out.print("Enter Phone number 1 ");
					String phoneno1=sc.next();
					hotel.setPhoneNo1(phoneno1);
					System.out.print("Enter Phone number 2");
					String phoneno2 = sc.next();
					hotel.setPhoneNo2(phoneno2);
					System.out.println("Enter rating");
					String rating=sc.next();
					hotel.setRating(rating);
					System.out.println("Enter email");
					String email=sc.next();
					hotel.setEmail(email);
					System.out.println("Enter fax");
					String fax=sc.next();
					hotel.setFax(fax);
					String k="";
					try {
						k = serv.addHotel(hotel);
					} catch (BookingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("Hotel added successfully with ID "+k);
					break;
				
				default:
					break;
				}
				
				
				
				
			}
		}	
		break;
		
		case 3:
		{
			c.login();
		}
		default: System.out.println("Invalid Option");
		break;
		}
		sc.close();
	}

	private void view() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Booking ID: ");
		String bid = sc.next();
		try {
			BookingDetails bookingDetails = service.viewBookingDetails(bid);
			System.out.println(bookingDetails);
		} catch (BookingException e) {
			System.out.println(e.getMessage());
		}
		sc.close();
	}

	private void search() {

		try {
			List<Hotel> hotelList = service.viewAllHotels();	
			for(Hotel hotel:hotelList)
			{
				System.out.println(hotel);
			}
		} catch (BookingException e) {
			System.out.println(e.getMessage());
		}
	}

	private void login() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter User ID ");
		String mobileno = sc.next();
		System.out.print("Enter Password: ");
		String password = sc.next();
		try {
			boolean flag = service.validateUser(mobileno, password);
			if(flag){
				System.out.print("\n\tMENU\n"
						+ "1. Search for hotel rooms.\n"
						+ "2. Book Hotel Rooms.\n"
						+ "3. View Booking Status.\n"
						+ " Enter choice: ");
				int ch = sc.nextInt();
				switch(ch)
				{
				case 1:
					this.search();
					break;
				case 2:
					this.book();
					break;
				case 3:
					this.view();
					break;
				default:
					break;	
				}
			}
			else
				System.out.println("Invalid User");

		} catch (BookingException e) {
			System.out.println(e.getMessage());
		}
		sc.close();
	}

	private void book() throws BookingException {

		Scanner sc = new Scanner(System.in);

		List<Hotel> hotelList = service.viewAllHotels();	
		for(Hotel hotel:hotelList)
		{
			System.out.println(hotel);
		}

		System.out.print("Enter Hotel ID: ");
		String hId = sc.next();
		try {
			List<Roomdetails> roomList = service.getAllRooms(hId);
			for(Roomdetails rd:roomList)
			{
				System.out.println(rd);
			}

			System.out.print("Enter Room ID to book Room: ");
			String roomId = sc.next();
			System.out.print("Enter your ID: ");
			String userId = sc.next();
			System.out.print("From (dd-MM-yyyy): ");
			String fdate = sc.next();  
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			LocalDate bookedFrom = LocalDate.parse(fdate, format);

			System.out.print("To (dd-MM-yyyy): ");
			String tdate = sc.next();  
			LocalDate bookedTo = LocalDate.parse(tdate, format);
			System.out.print("Total number of Adults: ");
			int noAdult = sc.nextInt();
			System.out.print("Total number of Childrens: ");
			int noChild = sc.nextInt();

			BookingDetails bookingDetails = new BookingDetails();
			bookingDetails.setRoomId(roomId);
			bookingDetails.setUserId(userId);
			bookingDetails.setBookedFrom(bookedFrom);
			bookingDetails.setBookedTo(bookedTo);
			bookingDetails.setNumberOfAdults(noAdult);
			bookingDetails.setNumberOfChildren(noChild);

			BookingDetails bid = service.addBookingDetails(bookingDetails);
			System.out.println("Your Booking ID: "+bid.getBookingId());
		} catch (BookingException e) {
			System.out.println(e.getMessage());
		}
		sc.close();
	}

	private void register() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Name: ");
		String name = sc.next();
		System.out.print("Enter Email id: ");
		String emailid = sc.next();
		System.out.print("Enter Phone number: ");
		String phoneno = sc.next();
		System.out.print("Enter Mobile number: ");
		String mobileno = sc.next();
		System.out.print("Enter Address: ");
		String addr = sc.next();
		System.out.print("Your role? (Customer): ");
		String role = sc.next();
		System.out.print("Create your Password: ");
		String pwd = sc.next();

		Users user = new Users();
		user.setAddress(addr);
		user.setEmail(emailid);
		user.setMobileNo(mobileno);
		user.setPassword(pwd);
		user.setPhone(phoneno);
		user.setRole(role);
		user.setUserName(name);
		try {
			boolean flag = true;
			if(flag){

				String uid = service.addUser(user);
				System.out.println("Your Booking Id is: "+uid );
			}
		}catch (BookingException e) {
			System.out.println(e.getMessage());
		}

		sc.close();
	}

}

/*
1.	Customer and Hotel-Employee should be able to 

�	Register into the system.
�	Login to the system using his/her credentials.
�	Search for hotel rooms.
�	Book hotel rooms.
�	View Booking Status

2.	The Admin should be able to

�	Login to the system using his/her credentials 
�	Perform Hotel Management (add/delete/modify Hotel info like description, any special offers etc)
�	Perform Room Management (add/delete/modify Room info like revised tariff) 
�	Generate various reports like:
	View List of Hotels
	View Bookings of specific hotel
	View guest list of specific hotel
    View bookings for specified date
 */

