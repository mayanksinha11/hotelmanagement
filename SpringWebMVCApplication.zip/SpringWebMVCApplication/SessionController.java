package com.cg.ss.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;




import com.cg.ss.dto.Session;
import com.cg.ss.service.ISessionService;



@Controller
public class SessionController {

	@Autowired
	ISessionService sessionservice;
	
	/*
	 * index.jsp will redirect the control to showall 
	 * then showAllSessionData function will run and controller will 
	 * be passed to service layer to show all the session deatils  
	 * */
	@RequestMapping(value="showall", method=RequestMethod.GET)
	public ModelAndView showAllSessionData(){
		List<Session> allSession=sessionservice.showAllSession();
		System.out.println(allSession);
		return new ModelAndView("ScheduledSessions","data",allSession);
		
	}
	
	/*
	 * Getting the Session name and passing it to Success.jsp to Display 
	 * */
	@RequestMapping(value="enrollme", method=RequestMethod.GET)
	public ModelAndView displayData(@RequestParam("sessionName") String sname){
		return new ModelAndView("Success","ename",sname);
	}
}
