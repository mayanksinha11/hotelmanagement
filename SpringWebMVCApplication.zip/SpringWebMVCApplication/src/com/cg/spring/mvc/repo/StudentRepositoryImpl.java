package com.cg.spring.mvc.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.mvc.beans.Student;
@Repository
public class StudentRepositoryImpl implements StudentRepository{	
	@PersistenceContext
	EntityManager manager;
	@Override
	public Student addStudent(Student student) {
		manager.persist(student);
		manager.flush();
		return student;
	}
	@Override
	public List<Student> getStudentList(String city) {
		String str=
		"select student from Student student where student.city=:cname";
		TypedQuery<Student> query= manager.createQuery(str, Student.class);
		query.setParameter("cname", city);
		List<Student> list=query.getResultList();
		return list;
		
	}
	@Override
	public List<String> getCityList() {
		String str="select distinct(student.city) from Student student";
		TypedQuery<String>  query=
				manager.createQuery(str, String.class);
		List<String> cityList= query.getResultList();
		return cityList;
	}
	@Override
	public List<Student> getStudentList() {
		String str="select student from Student student";
		TypedQuery<Student> query=manager.createQuery(str, Student.class);
		List<Student> list= query.getResultList();
		return list;
	}
	@Override
	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		manager.merge(student);
	}
	@Override
	public void deleteStudent(int id) {
		// TODO Auto-generated method stub
		Student student= manager.find(Student.class, id);
		manager.remove(student);
	}

}
