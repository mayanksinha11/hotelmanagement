import { Component} from '@angular/core';

@Component({
  selector: 'employee',
  templateUrl: `./employeecomponent.html`
  

})
export class Employee  {
employees:any[]=[{empid:1001,empname:"rahul",empsal:10000,empdept:"java"},
{empid:1002,empname:"mahesh",empsal:20000,empdept:"oracle"},{empid:1003,empname:"ramesh",empsal:30000,empdept:"sap"}
];

					}