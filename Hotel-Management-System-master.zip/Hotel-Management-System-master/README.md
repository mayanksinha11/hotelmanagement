# Hotel-Management-System
Hotel Management System Project built on Spring Boot
</br>
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/adilxiqbal/Hotel-Management-System/tree/heroku-server)

<h3>Stack</h3>
<ul>
  <li>Java 8</li>
  <li>Kotlin</li>
  <li>Maven 3</li>
  <li>Spring Boot - 2.0.0.RELEASE</li>
  <li>Heroku</li>
</ul>
