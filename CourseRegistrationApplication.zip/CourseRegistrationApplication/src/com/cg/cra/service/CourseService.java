package com.cg.cra.service;

import com.cg.cra.entity.Registration;

public interface CourseService {
	
	public Registration addcourse(Registration register);

}
