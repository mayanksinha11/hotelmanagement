package com.cg.cra.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.cra.entity.Registration;
@Service
@Transactional
public class CourseServiceImpl implements CourseService {

	@Override
	public Registration addcourse(Registration register) {
		// TODO Auto-generated method stub
		return null;
	}

}
