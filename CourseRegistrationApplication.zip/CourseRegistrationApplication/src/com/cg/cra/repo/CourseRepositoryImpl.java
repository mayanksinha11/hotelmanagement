package com.cg.cra.repo;

import com.cg.cra.entity.Registration;

public class CourseRepositoryImpl implements CourseRepository {

	@Override
	public Registration addcourse(Registration register) {
		// TODO Auto-generated method stub
		return null;
	}

}
