package com.cg.cra.repo;

import com.cg.cra.entity.Registration;

public interface CourseRepository {

	public Registration addcourse(Registration register) ;

}