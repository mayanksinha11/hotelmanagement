package com.cg.cra.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="registration")
public class Registration {
	@Id
	@SequenceGenerator(name="Id_seq",sequenceName="seq_reg_id",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="Id_seq")
	@Column(name="reg_id")
	private Integer regId;
	@Column(name="student_name")
	@NotEmpty(message="Student name is mandatory")
	@Pattern(regexp="[A-Z][a-z]{2,}",message="Student name should start with capital letter and should contain minimum 3 letters")
	private String studentName;
	
	@Column(name="phone")
	@NotEmpty(message="Please enter phone number")
	@Pattern(regexp="[0-9]{10}",message="Phone number should be 10 didgits only")
	private String phone;
	
	@Column(name="course_id")
	private int courseId;
	
	public Registration(){
		
	}

	public Integer getRegId() {
		return regId;
	}

	public void setRegId(Integer regId) {
		this.regId = regId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	
	
	
	
}
