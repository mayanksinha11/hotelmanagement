package com.cg.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotel;
import com.cg.bean.RoomDetails;
import com.cg.bean.Users;
import com.cg.exception.BookingException;

public interface IBookingDAO {

	public boolean validateDetails(Users user)throws BookingException;
	public String addUser(Users user)throws BookingException;//Hogaya
	public boolean validateUser(String mobileNo,String password)throws BookingException;
	public List<Hotel> viewAllHotels()throws BookingException;//Hogaya
	public List<RoomDetails> getAllRooms(String hotelId)throws BookingException;//Hogaya
	public BookingDetails addBookingDetails(BookingDetails bookingDetails)throws BookingException;
	public BookingDetails viewBookingDetails(String bookingId) throws BookingException;//Hogaya
	public String addHotel(Hotel hotel) throws BookingException;//Hogaya//me
	public int deleteHotel(String hotelId)throws BookingException;//apurva
	public boolean updateHotel(Hotel hotel)throws BookingException;//vansh
	public String addRoom(RoomDetails room) throws BookingException;//Hogaya
	public int deleteRoom(RoomDetails room)throws BookingException;//soumya
	public boolean updateRoom(RoomDetails room)throws BookingException;//updae
	public List<BookingDetails> adminViewBookingDetails(String hotelId)throws BookingException;//deepika
	public List<BookingDetails> getGuestList(String hotelId);
	
	public List<BookingDetails> viewBookings(LocalDate date)throws BookingException;//deepika

}
