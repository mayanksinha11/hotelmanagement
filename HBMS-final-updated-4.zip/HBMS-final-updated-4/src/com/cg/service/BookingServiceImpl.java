package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotel;
import com.cg.bean.RoomDetails;
import com.cg.bean.Users;
import com.cg.dao.BookingDAOImpl;
import com.cg.dao.IBookingDAO;
import com.cg.exception.BookingException;

public class BookingServiceImpl implements IBookingService{

	IBookingDAO dao;
	
	public BookingServiceImpl() {
		dao = new BookingDAOImpl();
	}
	@Override
	public boolean validateDetails(Users user) throws BookingException{
		
		return dao.validateDetails(user);
	}

	@Override
	public String addUser(Users user) throws BookingException{
		
		return dao.addUser(user);
	}

	@Override
	public boolean validateUser(String mobileNo, String password)
			throws BookingException {
		
		return dao.validateUser(mobileNo, password);
	}

	@Override
	public List<Hotel> viewAllHotels() throws BookingException {
		
		return dao.viewAllHotels();
	}

	@Override
	public List<RoomDetails> getAllRooms(String hotelId)
			throws BookingException {
		
		return dao.getAllRooms(hotelId);
	}

	@Override
	public BookingDetails addBookingDetails(BookingDetails bookingDetails)
			throws BookingException {
		
		return dao.addBookingDetails(bookingDetails);
	}

	@Override
	public BookingDetails viewBookingDetails(String bookingId)
			throws BookingException {
		
		return dao.viewBookingDetails(bookingId);
	}
	@Override
	public String addHotel(Hotel hotel) throws BookingException {
		// TODO Auto-generated method stub
		return dao.addHotel(hotel);
	}
	@Override
	public String addRoom(RoomDetails room) throws BookingException{
		// TODO Auto-generated method stub
		return dao.addRoom(room);
	}
	@Override
	public List<BookingDetails> viewBookings(LocalDate date)throws BookingException {
		// TODO Auto-generated method stub
		return dao.viewBookings(date);
	}
	@Override
	public List<BookingDetails> getGuestList(String hotelId) {
		// TODO Auto-generated method stub
		return dao.getGuestList(hotelId);
	}
	@Override
	public List<BookingDetails> adminViewBookingDetails(String hotelId)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.adminViewBookingDetails(hotelId);
	}
	@Override
	public int deleteRoom(RoomDetails room) throws BookingException {
		// TODO Auto-generated method stub
		return dao.deleteRoom(room);
	}
	@Override
	public boolean updateRoom(RoomDetails room) throws BookingException {
		// TODO Auto-generated method stub
		return dao.updateRoom(room);
	}
	@Override
	public int deleteHotel(String hotelId)throws BookingException {
		// TODO Auto-generated method stub
		return dao.deleteHotel(hotelId);
	}

	

}
