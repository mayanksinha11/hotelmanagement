package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;




import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotel;
import com.cg.bean.Roomdetails;
import com.cg.bean.Users;
import com.cg.exception.BookingException;
import com.cg.util.DatabaseConnection;


public class BookingDAOImpl implements IBookingDAO{

	Connection con=null;
	Logger logger = Logger.getRootLogger();

	public BookingDAOImpl() {
		PropertyConfigurator.configure("resources\\log4j.properties");   
		con = DatabaseConnection.getConnection(); 
		System.out.println(con);
	}


	public String generateUserId(Users user) throws BookingException{
		int id=0;
		String strId=null;
		String str = "select User_Id_Seq.nextval from dual";
		String str1;
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(str);
			while(rs.next())
			{
				id = rs.getInt(1);
			}
			str1=user.getRole();
			System.out.println(str1);
			if(str1.equalsIgnoreCase("customer"))
				strId = "U"+id;

		} catch (SQLException e) {
			logger.error("Cannot generate user id.....");
			throw new BookingException("Cannot generate user id.....");
		}
		System.out.println(strId);
		return strId;

	}

	private String generateBookingId() throws BookingException{    // Auto generation of Patient id.

		int id=0;
		String strId=null;
		String str = "select Booking_Id_Seq.nextval from dual";

		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(str);
			while(rs.next())
			{
				id = rs.getInt(1);
			}

			String abc=Integer.toString(id);
			strId="B".concat(abc);
		}
		catch (SQLException e) {
			logger.error("Cannot generate user id.....");
			throw new BookingException("Cannot generate user id.....");
		}

		return strId;
	}

	/*@Override
	public boolean validateDetails(Users user) throws BookingException
	{

		Pattern pattern=Pattern.compile("[A-Z a-z 0-9]{5,10}");
		Matcher matcher= pattern.matcher(user.getPassword());
		if(matcher.matches()){

			pattern=Pattern.compile("[A-Z]{1}[a-z]{7}");
			matcher= pattern.matcher(user.getRole());
			if(matcher.matches()){

				pattern=Pattern.compile("[A-Z][a-z]{1,19}");
				matcher= pattern.matcher(user.getUserName());
				if(matcher.matches()){

					pattern= Pattern.compile("[0-9]{10}");
					matcher= pattern.matcher(user.getMobileNo());
					if(matcher.matches()){	

						pattern= Pattern.compile("[0-9]{10}");
						matcher= pattern.matcher(user.getPhone());
						if(matcher.matches()){	

							pattern= Pattern.compile("[a-z0-9]*@user.com");
							matcher= pattern.matcher(user.getEmail());

							if(matcher.matches()){
								return true;
							}
							else 
								throw new BookingException("Invalid Email.. ");
						}
						else
							throw new BookingException("Invalid Phone Number..");
					}
					else
						throw new BookingException("Invalid Mobile Number..");
				}
				else
					throw new BookingException("Invalid User Name..");		
			}
			else
				throw new BookingException("Invalid Role..");		
		}
		else
			throw new BookingException("Invalid Password..");	
	}
*/

	@Override
	public String addUser(Users user) throws BookingException{
		user.setUserId(generateUserId(user));

		String query = "insert into Users(user_id,password,role,user_name,mobile_no,phone,address,email) values(?,?,?,?,?,?,?,?)";

		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, user.getUserId());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getRole());
			ps.setString(4, user.getUserName());
			ps.setString(5,user.getMobileNo());
			ps.setString(6,user.getPhone());
			ps.setString(7, user.getAddress());
			ps.setString(8,user.getEmail());

			int row = ps.executeUpdate();
			logger.info(row+" User details are added successfully....");
			ps.close();
		} catch (SQLException e) {
			logger.error("Cannot add User details....");
			throw new BookingException("Cannot add User details....");  
		}
		try {
			con.close();
		} catch (SQLException e) {
			logger.error("Error in closing database connection....");
			throw new BookingException("Error in closing database connection....");
		}
		return user.getUserId();
	}

	@Override
	public boolean validateUser(String mobileNo, String password)
			throws BookingException {

		String query = "select mobile_no,password from Users where mobile_no= ? and password = ? ";
		boolean flag=false;
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, mobileNo);
			ps.setString(2, password);
			ResultSet res=ps.executeQuery();
			while(res.next())
			{
				flag=true;
			}	
		}
		catch(Exception e)
		{

		}

		return flag;
	}

	@Override
	public List<Hotel> viewAllHotels() throws BookingException {

		List<Hotel> hotellist=new ArrayList<Hotel>();
		String query="select * from Hotel";
		try {

			PreparedStatement ps=con.prepareStatement(query);
			ResultSet res=ps.executeQuery();
			while(res.next())
			{
				Hotel h=new Hotel();
				h.setHotelId(res.getString("hotel_id"));
				h.setHotelName(res.getString("hotel_name"));
				h.setCity(res.getString("city"));
				h.setAddress(res.getString("address"));
				h.setDescription(res.getString("description"));
				h.setAverageRatePerNight(res.getDouble("avg_rate_per_night"));
				h.setRating(res.getString("rating"));
				h.setEmail(res.getString("email"));
				h.setFax(res.getString("fax"));
				h.setPhoneNo1(res.getString("phone_no1"));
				h.setPhoneNo2(res.getString("phone_no2"));
				hotellist.add(h);
			}
		}catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BookingException(e.getMessage());
		}
		return hotellist;
	}

	@Override
	public List<Roomdetails> getAllRooms(String hotelId)
			throws BookingException {

		List<Roomdetails> roomDetails=new ArrayList<Roomdetails>();
		String query="select room_id,room_no,room_type,per_night_rate,availability from roomdetails where hotel_id = ?";
		try {

			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, hotelId);
			ResultSet res=ps.executeQuery();
			while(res.next())
			{
				Roomdetails rd=new Roomdetails();
				rd.setHotelId(hotelId);
				rd.setRoomId(res.getString("room_id"));
				rd.setRoomNo(res.getString("room_no"));
				rd.setRoomType(res.getString("room_type"));
				rd.setPerNightRate(res.getDouble("per_night_rate"));
				rd.setAvailability(res.getInt("availability"));

				roomDetails.add(rd);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return roomDetails;
	}

	@Override
	public BookingDetails addBookingDetails(BookingDetails bookingDetails)
			throws BookingException {

		bookingDetails.setBookingId(generateBookingId());
		String sql="insert into BookingDetails(booking_id,room_id,user_id,booked_from,booked_to,no_of_adults,no_of_children,amount) values(?,?,?,?,?,?,?,?)";
		String query="select per_night_rate from roomdetails where room_id=?";


		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setString(1, bookingDetails.getBookingId());
			ps.setString(2, bookingDetails.getRoomId());
			ps.setString(3,bookingDetails.getUserId());
			Date sqlDate1= Date.valueOf(bookingDetails.getBookedFrom());
			ps.setDate(4,sqlDate1);
			Date sqlDate2= Date.valueOf(bookingDetails.getBookedTo());
			ps.setDate(5,sqlDate2);
			ps.setInt(6,bookingDetails.getNumberOfAdults());
			ps.setInt(7,bookingDetails.getNumberOfChildren());

			PreparedStatement ps1=con.prepareStatement(query);
			ps1.setString(1, bookingDetails.getRoomId());
			ResultSet res=ps1.executeQuery();

			int date1=sqlDate1.getDate();
			int date2=sqlDate2.getDate();
			int days=date2-date1;
			if(days<0)
			{
				throw new BookingException("Invalid Dates");
			}
			else
			{
				Double amount=0.0;
				while(res.next())
				{
					amount=res.getDouble("per_night_rate");
				}
				amount=amount*days;
				ps.setDouble(8, amount);
				ps.executeUpdate();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return bookingDetails;
	}



	@Override
	public BookingDetails viewBookingDetails(String bookingId)
			throws BookingException {

		BookingDetails book=new BookingDetails();
		String sql="select booking_id,room_id,user_id,booked_from,booked_to,no_of_adults,no_of_children,amount from BookingDetails where booking_id=? ";
		LocalDate dt1=null;
		LocalDate dt2=null;
		try{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,bookingId);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				String  bookId=rs.getString("booking_id");
				String roomId=rs.getString("room_id");
				String userId=rs.getString("user_id");
				Date date1=rs.getDate("booked_from");
				if(date1!=null){
					dt1=date1.toLocalDate();
				}
				Date date2=rs.getDate("booked_to");
				if(date2!=null){
					dt2=date2.toLocalDate();
				}
				int adult=rs.getInt("no_of_adults");
				int children=rs.getInt("no_of_children");
				double amt=rs.getDouble("amount");
	//			System.out.println(bookId +" "+roomId+userId+dt1+dt2+adult+children+amt);
				book.setBookingId(bookId);
				book.setRoomId(roomId);
				book.setUserId(userId);
				book.setBookedFrom(dt1);
				book.setBookedTo(dt2);
				book.setNumberOfAdults(adult);
				book.setNumberOfChildren(children);
				book.setAmount(amt);

			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}	
		return book;
	}


	@Override
	public boolean validateDetails(Users user) throws BookingException {
		// TODO Auto-generated method stub
		return false;
	}	
}
